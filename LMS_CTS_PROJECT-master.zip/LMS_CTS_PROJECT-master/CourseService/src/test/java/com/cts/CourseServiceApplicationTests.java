package com.cts;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import com.cts.exception.CourseNotFound;
import com.cts.feignclient.EnrollmentClient;
import com.cts.feignclient.QuizClient;
import com.cts.model.Course;
import com.cts.repository.CourseRepository;
import com.cts.service.CourseServiceImpl;

@SpringBootTest
class CourseServiceImplTest {

    @Mock
    private CourseRepository repository;

    @Mock
    private EnrollmentClient enrollmentClient;

    @Mock
    private QuizClient quizClient;

    @InjectMocks
    private CourseServiceImpl service;

    private Course mockCourse;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        mockCourse = new Course(
        	    1, 
        	    "Java Basics", 
        	    "Introduction to Java", 
        	    "Programming", 
        	    101, 
        	    "Basic coding skills", 
        	    30, 
        	    "https://example.com/video.jpg",
        	    "Course content here...",
        	    Arrays.asList("https://example.com/video1", "https://example.com/video2")
        	);
    }

    @Test
    void createCourseTest() {
        when(repository.findById(mockCourse.getCourseId())).thenReturn(Optional.empty());
        when(repository.save(mockCourse)).thenReturn(mockCourse);

        String response = service.createCourse(mockCourse);
        assertEquals("Course Saved Successfully", response);

        verify(repository, times(1)).save(mockCourse);
    }

    @Test
    void createCourseAlreadyExistsTest() {
        when(repository.findById(mockCourse.getCourseId())).thenReturn(Optional.of(mockCourse));

        String response = service.createCourse(mockCourse);
        assertEquals("Course Already Exists", response);
    }

    @Test
    void updateCourseTest() throws CourseNotFound {
        when(repository.findById(mockCourse.getCourseId())).thenReturn(Optional.of(mockCourse));
        when(repository.save(mockCourse)).thenReturn(mockCourse);

        Course updatedCourse = service.updateCourse(mockCourse);
        assertEquals(mockCourse, updatedCourse);

        verify(repository, times(1)).save(mockCourse);
    }

    @Test
    void updateCourseNotFoundTest() {
        when(repository.findById(mockCourse.getCourseId())).thenReturn(Optional.empty());

        assertThrows(CourseNotFound.class, () -> service.updateCourse(mockCourse));
    }

    @Test
    void deleteCourseTest() throws CourseNotFound {
        when(repository.findById(mockCourse.getCourseId())).thenReturn(Optional.of(mockCourse));
        doNothing().when(repository).deleteById(mockCourse.getCourseId());

        String response = service.deleteCourse(mockCourse.getCourseId());
        assertEquals("Course Deleted Successfully", response);

        verify(repository, times(1)).deleteById(mockCourse.getCourseId());
        verify(enrollmentClient, times(1)).cancelEnrollmentsByCourseId(mockCourse.getCourseId());
        verify(quizClient, times(1)).deleteQuizByCourseId(mockCourse.getCourseId());
    }

    @Test
    void deleteCourseNotFoundTest() {
        when(repository.findById(mockCourse.getCourseId())).thenReturn(Optional.empty());

        assertThrows(CourseNotFound.class, () -> service.deleteCourse(mockCourse.getCourseId()));

        verify(repository, never()).deleteById(anyInt());
        verify(enrollmentClient, never()).cancelEnrollmentsByCourseId(anyInt());
        verify(quizClient, never()).deleteQuizByCourseId(anyInt());
    }

    @Test
    void getCourseTest() throws CourseNotFound {
        when(repository.findById(mockCourse.getCourseId())).thenReturn(Optional.of(mockCourse));

        Course foundCourse = service.getCourse(mockCourse.getCourseId());
        assertEquals(mockCourse, foundCourse);

        verify(repository, times(1)).findById(mockCourse.getCourseId());
    }

    @Test
    void getCourseNotFoundTest() {
        when(repository.findById(mockCourse.getCourseId())).thenReturn(Optional.empty());

        assertThrows(CourseNotFound.class, () -> service.getCourse(mockCourse.getCourseId()));
    }

    @Test
    void getAllCoursesTest() {
        List<Course> courses = Arrays.asList(
        		new Course(
        			    1, 
        			    "Python Basics", 
        			    "Intro to Python", 
        			    "Programming", 
        			    106, 
        			    "No prerequisites", 
        			    40, 
        			    "https://example.com/python-image.jpg", 
        			    "Python course content goes here...", 
        			    Arrays.asList("https://example.com/python-video1", "https://example.com/python-video2")
        			),
        			new Course(
        			    2, 
        			    "Angular Advanced", 
        			    "Frontend framework deep dive", 
        			    "Web", 
        			    107, 
        			    "Basic HTML", 
        			    45, 
        			    "https://example.com/angular-image.jpg", 
        			    "Angular course content goes here...", 
        			    Arrays.asList("https://example.com/angular-video1", "https://example.com/angular-video2")
        			));


        when(repository.findAll()).thenReturn(courses);

        List<Course> allCourses = service.getAllCourses();
        assertEquals(2, allCourses.size());
        assertEquals(courses, allCourses);

        verify(repository, times(1)).findAll();
    }

    @Test
    void checkCourseExistTest() throws CourseNotFound {
        when(repository.existsById(mockCourse.getCourseId())).thenReturn(true);

        assertTrue(service.checkCourseExist(mockCourse.getCourseId()));

        verify(repository, times(1)).existsById(mockCourse.getCourseId());
    }

    @Test
    void checkCourseDoesNotExistTest() {
        when(repository.existsById(mockCourse.getCourseId())).thenReturn(false);

        assertThrows(CourseNotFound.class, () -> service.checkCourseExist(mockCourse.getCourseId()));
    }
}
