package com.cts.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.exception.CourseNotFound;
import com.cts.feignclient.EnrollmentClient;
import com.cts.feignclient.QuizClient;
import com.cts.model.Course;
import com.cts.repository.CourseRepository;

@Service
public class CourseServiceImpl implements CourseService {
	@Autowired
	CourseRepository repository;
	@Autowired
	EnrollmentClient enrollmentClient;

	@Autowired
	QuizClient quizClient;

	Logger log = LoggerFactory.getLogger(CourseServiceImpl.class);

	// Used To Create Course
	@Override
    public String createCourse(Course course) {
        log.info("Creating course...");
        Optional<Course> optional = repository.findById(course.getCourseId());
        if (optional.isPresent()) {
            return "Course Already Exists";
        }
        Course savedCourse = repository.save(course);
        return savedCourse != null ? "Course Saved Successfully" : "Course Not Saved";
    }

    @Override
    public Course updateCourse(Course course) throws CourseNotFound {
        log.info("Updating course...");
        Optional<Course> optional = repository.findById(course.getCourseId());
        if (optional.isPresent()) {
            Course updatedCourse = optional.get();
            updatedCourse.setCourseTitle(course.getCourseTitle());
            updatedCourse.setCourseDescription(course.getCourseDescription());
            updatedCourse.setCourseCategory(course.getCourseCategory());
            updatedCourse.setPrerequisites(course.getPrerequisites());
            updatedCourse.setCourseDuration(course.getCourseDuration());
            updatedCourse.setImageUrl(course.getImageUrl()); // ✅ Updating video URL
            updatedCourse.setCourseContent(course.getCourseContent());
            updatedCourse.setVideoLinks(course.getVideoLinks());
            return repository.save(updatedCourse);
        } else {
            throw new CourseNotFound("Course Id is Invalid...");
        }
    }

    @Override
    public Course getCourse(int courseId) throws CourseNotFound {
        log.info("Fetching course...");
        Optional<Course> optional = repository.findById(courseId);
        if (optional.isPresent()) {
            return optional.get();
        } else {
            log.error("Course ID {} not found", courseId);
            throw new CourseNotFound("Course ID is Invalid...");
        }
    }

    @Override
    public List<Course> getAllCourses() {
        log.info("Fetching all courses...");
        return repository.findAll();
    }

    @Override
    public String deleteCourse(int courseId) throws CourseNotFound {
        log.info("Deleting course...");
        Optional<Course> optional = repository.findById(courseId);
        if (optional.isPresent()) {
            repository.deleteById(courseId);
            try {
                enrollmentClient.cancelEnrollmentsByCourseId(courseId);
                quizClient.deleteQuizByCourseId(courseId);
            } catch (Exception e) {
                log.error("Failed to clean up related data for course ID {}", courseId, e);
                throw new RuntimeException("Failed to clean up related data");
            }
            return "Course Deleted Successfully";
        } else {
            throw new CourseNotFound("Course ID is Invalid...");
        }
    }
    
	// Used To Check Whether the Course Exist in DataBase
	@Override
	public Boolean checkCourseExist(int courseId) throws CourseNotFound {
		log.info("In CourseServiceImpl checkCourseExist method...");

		Boolean response = repository.existsById(courseId);
		if (response) {
			return response;
		} else {
			throw new CourseNotFound("Course Id is Invalid....");
		}
	}

}
