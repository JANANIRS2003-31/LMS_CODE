package com.example.demo.notification;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
 
@SpringBootApplication(scanBasePackages = {"com.example.demo", "com.cts.demo.notification"})
@EnableDiscoveryClient
public class MailNotificationApplication {
 
	public static void main(String[] args) {
		SpringApplication.run(MailNotificationApplication.class, args);
	}
}