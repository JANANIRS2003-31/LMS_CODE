package com.cts.exception;

public class QuizNotFound extends Exception {
	public QuizNotFound(String message) {
		super(message);
	}
}
