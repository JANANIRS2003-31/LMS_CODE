package com.cts.exception;

public class QuizSubmissionNotFound extends Exception {
	public QuizSubmissionNotFound(String message) {
		super(message);
	}
}
