package com.cts;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.cts.dto.QuizSubmissionDTO;
import com.cts.exception.QuizNotFound;
import com.cts.exception.QuizSubmissionNotFound;
import com.cts.feignclient.CourseClient;
import com.cts.feignclient.EnrollmentClient;
import com.cts.feignclient.UserClient;
import com.cts.model.Quiz;
import com.cts.model.QuizSubmission;
import com.cts.repository.QuizRepository;
import com.cts.repository.QuizSubmissionRepository;
import com.cts.service.QuizServiceImpl;

class QuizServiceImplTest {

    @Mock
    private QuizRepository quizRepository;

    @Mock
    private QuizSubmissionRepository submissionRepository;

    @Mock
    private UserClient userClient;

    @Mock
    private CourseClient courseClient;

    @Mock
    private EnrollmentClient enrollmentClient;

    @InjectMocks
    private QuizServiceImpl quizService;

    private Quiz mockQuiz;
    private QuizSubmission mockSubmission;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        mockQuiz = new Quiz(101, 201, "Cloud Computing Quiz", 50, new HashMap<>(), new HashMap<>(), new HashMap<>());
        mockSubmission = new QuizSubmission(1, 101, 5001, Map.of(1, "Cloud Computing", 2, "Wrong Answer"), 0, false);
    }

    @Test
    void testCreateQuiz_Success() {
        when(courseClient.checkCourseExist(mockQuiz.getCourseId())).thenReturn(true);
        when(quizRepository.save(mockQuiz)).thenReturn(mockQuiz);

        String result = quizService.createQuiz(mockQuiz);

        assertEquals("Quiz Created Successfully", result);
        verify(quizRepository, times(1)).save(mockQuiz);
    }

    @Test
    void testGetQuizById_Success() throws QuizNotFound {
        when(quizRepository.findById(101)).thenReturn(Optional.of(mockQuiz));

        Quiz foundQuiz = quizService.getQuizById(101);

        assertNotNull(foundQuiz);
        assertEquals("Cloud Computing Quiz", foundQuiz.getTitle());
    }

    @Test
    void testGetQuizById_NotFound() {
        when(quizRepository.findById(101)).thenReturn(Optional.empty());

        assertThrows(QuizNotFound.class, () -> quizService.getQuizById(101));
    }

    @Test
    void testDeleteQuiz_Success() throws QuizNotFound {
        when(quizRepository.findById(101)).thenReturn(Optional.of(mockQuiz));

        String result = quizService.deleteQuiz(101);

        assertEquals("Quiz Deleted", result);
        verify(quizRepository, times(1)).delete(mockQuiz);
    }

    @Test
    void testDeleteQuiz_NotFound() {
        when(quizRepository.findById(101)).thenReturn(Optional.empty());

        assertThrows(QuizNotFound.class, () -> quizService.deleteQuiz(101));
    }

    @Test
    void testEvaluateQuiz_Success() throws QuizNotFound, QuizSubmissionNotFound {
        Map<Integer, String> correctAnswers = Map.of(
            1, "Cloud Computing",
            2, "Virtualization"
        );

        Map<Integer, List<String>> options = Map.of(
            1, List.of("Cloud Computing", "Big Data"),
            2, List.of("Virtualization", "Networking")
        );

        mockQuiz.setCorrectAnswers(correctAnswers);
        mockQuiz.setOptions(options);

        mockSubmission.setResponses(Map.of(
            1, "Cloud Computing",  
            2, "Wrong Answer"      
        ));

        when(quizRepository.findById(101)).thenReturn(Optional.of(mockQuiz));
        when(submissionRepository.findByUserIdAndQuizId(5001, 101)).thenReturn(null);

        QuizSubmissionDTO evaluatedSubmission = quizService.evaluateQuiz(mockSubmission);

        assertEquals(10, evaluatedSubmission.getScore(), "Expected 10 points for one correct answer");
        assertFalse(evaluatedSubmission.isPassed(), "User should fail since not enough correct answers");
        assertEquals(1, evaluatedSubmission.getCorrectAnswersCount(), "Expected 1 correct answer");
        assertEquals(1, evaluatedSubmission.getIncorrectAnswersCount(), "Expected 1 incorrect answer");

        System.out.println("Final Score: " + evaluatedSubmission.getScore());
        System.out.println("Correct Answers Count: " + evaluatedSubmission.getCorrectAnswersCount());
        System.out.println("Incorrect Answers Count: " + evaluatedSubmission.getIncorrectAnswersCount());
    }


    @Test
    void testEvaluateQuiz_QuizNotFound() {
        when(quizRepository.findById(101)).thenReturn(Optional.empty());

        assertThrows(QuizNotFound.class, () -> quizService.evaluateQuiz(mockSubmission));
    }

    @Test
    void testEvaluateQuiz_SubmissionAlreadyExists() {
        when(quizRepository.findById(101)).thenReturn(Optional.of(mockQuiz));
        when(submissionRepository.findByUserIdAndQuizId(5001, 101)).thenReturn(mockSubmission);

        assertThrows(QuizSubmissionNotFound.class, () -> quizService.evaluateQuiz(mockSubmission));
    }

    @Test
    void testGetAllQuizzes() {
        when(quizRepository.findAll()).thenReturn(List.of(mockQuiz));

        List<Quiz> quizzes = quizService.getAllQuizzes();

        assertEquals(1, quizzes.size());
    }

    @Test
    void testGetAllQuizSubmissionsByUser_Success() throws QuizSubmissionNotFound {
        when(userClient.checkUserExist(5001)).thenReturn(true);
        when(submissionRepository.findByUserId(5001)).thenReturn(List.of(mockSubmission));

        List<QuizSubmission> submissions = quizService.getAllQuizSubmissionByUserId(5001);

        assertEquals(1, submissions.size());
    }

    @Test
    void testGetAllQuizSubmissionsByUser_NotFound() {
        when(userClient.checkUserExist(5001)).thenReturn(true);
        when(submissionRepository.findByUserId(5001)).thenReturn(List.of());

        assertThrows(QuizSubmissionNotFound.class, () -> quizService.getAllQuizSubmissionByUserId(5001));
    }

    @Test
    void testDeleteQuizByCourseId() {
        String result = quizService.deleteQuizByCourseId(201);

        assertEquals("All the quizzes deleted", result);
        verify(quizRepository, times(1)).deleteByCourseId(201);
    }
}
