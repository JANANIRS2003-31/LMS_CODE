package com.cts.feignclient;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import com.cts.dto.CourseDTO;
import com.cts.dto.EnrollmentDTO;


@FeignClient(name = "ENROLLMENTSERVICE", path = "/enroll")
public interface EnrollmentClient {
	@GetMapping("/fetchCoursesByUserId/{uid}")
	public List<CourseDTO> getCoursesByUserId(@PathVariable("uid") int userId);

	@GetMapping("/getAllCourses")
    public List<CourseDTO> getAllCourses();
	
	@GetMapping("/fetchAll")
	public List<EnrollmentDTO> getAllEnrollments();
}
