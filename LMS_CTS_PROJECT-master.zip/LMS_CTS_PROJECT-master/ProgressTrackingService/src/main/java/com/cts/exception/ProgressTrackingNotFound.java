package com.cts.exception;

public class ProgressTrackingNotFound extends Exception {
	public ProgressTrackingNotFound(String message) {
		super(message);
	}
}
