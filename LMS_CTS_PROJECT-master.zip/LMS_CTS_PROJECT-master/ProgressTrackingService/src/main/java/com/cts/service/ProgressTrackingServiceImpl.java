package com.cts.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.dto.CourseDTO;
import com.cts.dto.CourseProgressDTO;
import com.cts.dto.EnrollmentDTO;
import com.cts.dto.QuizDTO;
import com.cts.dto.QuizProgressDTO;
import com.cts.dto.QuizSubmissionDTO;
import com.cts.dto.UserDTO;
import com.cts.feignclient.EnrollmentClient;
import com.cts.feignclient.QuizClient;
@Service
public class ProgressTrackingServiceImpl implements ProgressTrackingService {
	@Autowired
	EnrollmentClient enrollmentClient;
	
	@Autowired
	QuizClient quizClient;
	
	Logger log = LoggerFactory.getLogger(ProgressTrackingServiceImpl.class);

	
	// Used To Get Courses By User Id
	@Override
	public List<CourseDTO> getCourseByUserId(int userId) {
		log.info("In ProgressTrackingServiceImpl getCourseByUserId method...");

		return enrollmentClient.getCoursesByUserId(userId);
	}
	
	// Used To Get Progress For A Particular User
	@Override
	public UserDTO getProgressByUserId(int userId) {
	    log.info("Fetching progress for User ID: {}", userId);

	    List<CourseDTO> courses = enrollmentClient.getCoursesByUserId(userId);
	    List<CourseProgressDTO> courseProgressDTOs = new ArrayList<>();

	    for (CourseDTO course : courses) {
	        int courseId = course.getCourseId();
	        List<QuizDTO> quizzes = quizClient.getQuizByCourseId(courseId);
	        List<QuizProgressDTO> quizProgressDTOs = new ArrayList<>();

	        int totalQuizCount = quizzes.size();
	        int totalQuizScore = 0;
	        int totalMarksPossible = 0;
	        int completedQuizzes = 0;

	        for (QuizDTO quiz : quizzes) {
	            QuizSubmissionDTO submissionDTO = quizClient.getQuizSubmissionByUserIdAndQuizId(userId, quiz.getQuizId());

	            int totalMarks = quiz.getTotalMarks();
	            int score = (submissionDTO != null) ? submissionDTO.getScore() : 0;
	            totalQuizScore += score;
	            totalMarksPossible += totalMarks;

	            double quizProgressPercentage = (totalMarks > 0) ? ((double) score / totalMarks) * 100 : 0;

	            if (submissionDTO != null && submissionDTO.isPassed()) {
	                completedQuizzes++; // Count completed quizzes correctly
	            }

	            quizProgressDTOs.add(new QuizProgressDTO(quiz.getQuizId(), totalMarks, score, quizProgressPercentage));
	        }

	        
	        double courseCompletionPercentage = (totalQuizCount > 0)
	            ? ((double) completedQuizzes / totalQuizCount) * 100
	            : 0;

	        courseProgressDTOs.add(new CourseProgressDTO(
	            courseId, course.getCourseTitle(), course.getCourseDescription(), quizProgressDTOs, courseCompletionPercentage));
	    }

	    return new UserDTO(userId, courseProgressDTOs);
	}

	
	@Override
	public List<UserDTO> getAllProgress() {
	    log.info("Fetching progress for all users...");

	    List<EnrollmentDTO> enrollments = enrollmentClient.getAllEnrollments();
	    List<UserDTO> userProgressList = new ArrayList<>();

	    for (EnrollmentDTO enrollment : enrollments) {
	        int userId = enrollment.getUserId();
	        UserDTO userProgress = getProgressByUserId(userId);
	        userProgressList.add(userProgress);
	    }

	    return userProgressList;
	}
	
	@Override
	public Map<String, Integer> getCourseEnrollmentStats() {
	    log.info("Fetching course enrollment statistics...");

	    // Fetch all enrollments
	    List<EnrollmentDTO> enrollments = enrollmentClient.getAllEnrollments();

	    // Fetch all courses
	    List<CourseDTO> courses = enrollmentClient.getAllCourses();

	    // Create a mapping of courseId -> courseTitle
	    Map<Integer, String> courseTitleMap = new HashMap<>();
	    for (CourseDTO course : courses) {
	        courseTitleMap.put(course.getCourseId(), course.getCourseTitle());
	    }

	    // Create a map to store course enrollments
	    Map<String, Integer> courseEnrollmentMap = new HashMap<>();

	    for (EnrollmentDTO enrollment : enrollments) {
	        int courseId = enrollment.getCourseId(); // Assuming EnrollmentDTO contains courseId
	        String courseTitle = courseTitleMap.get(courseId); // Get the corresponding course title

	        if (courseTitle != null) {
	            courseEnrollmentMap.put(courseTitle, courseEnrollmentMap.getOrDefault(courseTitle, 0) + 1);
	        }
	    }

	    return courseEnrollmentMap;
	}



}
