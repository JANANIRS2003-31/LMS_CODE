package com.cts.exception;

public class EnrollmentNotFound extends Exception {
	public EnrollmentNotFound(String message) {
		super(message);
	}
}
