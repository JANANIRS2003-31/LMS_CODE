package com.cts.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;

import com.cts.dto.Course;
import com.cts.dto.User;
import com.cts.dto.UserCourseEnrollResponseDTO;
import com.cts.exception.EnrollmentNotFound;
import com.cts.feignclient.CourseClient;
import com.cts.feignclient.UserClient;
import com.cts.model.Enrollment;
import com.cts.repository.EnrollmentRepository;

import jakarta.transaction.Transactional;

@Service
public class EnrollmentServiceImpl implements EnrollmentService {
	@Autowired
	EnrollmentRepository repository;

	@Autowired
	UserClient userClient;

	@Autowired
	CourseClient courseClient;

	Logger log = LoggerFactory.getLogger(EnrollmentServiceImpl.class);

	@Override
	public String saveEnrollment(Enrollment enrollment) {
		log.info("In EnrollmentServiceImpl saveEnrollment method...");

		int userId = enrollment.getUserId();
		int courseId = enrollment.getCourseId();
		// Check User Exist By Communication
		Boolean responseUser = userClient.checkUserExist(userId);
		// Check Course Exist By Communication
		Boolean responseCourse = courseClient.checkCourseExist(courseId);
		// Check Enrollment Aldready Exist
		Enrollment enrollmentExist = repository.findByUserIdAndCourseId(userId, courseId);
		if (enrollmentExist != null) {
			return "Enrollment Already Exist";
		}
		repository.save(enrollment);
		return "Enrollment Successfully Saved";
	}

	// Used To Update Enrollment

	@Override
	public Enrollment updateEnrollment(Enrollment enrollment) throws EnrollmentNotFound {
		log.info("In EnrollmentServiceImpl updateEnrollment method...");

		int userId = enrollment.getUserId();
		int courseId = enrollment.getCourseId();
		// Check User Exist By Communication

		Boolean responseUser = userClient.checkUserExist(userId);
		// Check Course Exist By Communication

		Boolean responseCourse = courseClient.checkCourseExist(courseId);
		Optional<Enrollment> enrollmentExist = repository.findById(enrollment.getEnrollmentId());
		// Check Enrollment Aldready Exist to Update

		if (enrollmentExist.isPresent())
			return repository.save(enrollment);

		else
			throw new EnrollmentNotFound("Enrollment Id is Invalid...");

	}


	@Override
	public String cancelEnrollment(int enrollmentId) throws EnrollmentNotFound {
		log.info("In EnrollmentServiceImpl cancelEnrollment method...");

		Optional<Enrollment> optional = repository.findById(enrollmentId);
		// Check It Is Exist Or Not
		if (optional.isPresent()) {
			repository.delete(repository.findById(enrollmentId).get());
			return "Enrollment Deleted";
		}
		throw new EnrollmentNotFound("Enrollment Id is Invalid");
	}

	@Override
	public List<Enrollment> getAllEnrollments() {
		log.info("In EnrollmentServiceImpl cancelEnrollment method...");

		return repository.findAll();
	}


	@Override
	public List<Enrollment> getEnrollmentsByUser(int userId) throws EnrollmentNotFound {
		log.info("In EnrollmentServiceImpl getEnrollmentByUser method...");
		// Check User Exist By Communication
		Boolean responseUser = userClient.checkUserExist(userId);
		List<Enrollment> list = repository.findByUserId(userId);
		// Check Enrollment Exist For that User
		if (list.isEmpty())
			throw new EnrollmentNotFound("No Enrollments For this User Found");
		return list;
	}

	@Override
	public List<User> getUsersByCourseId(int courseId) {
		log.info("In EnrollmentServiceImpl getUsersByCourseId method...");

		Boolean responseCourse = courseClient.checkCourseExist(courseId);
		List<Enrollment> list = repository.findByCourseId(courseId);
//		if(list.isEmpty()) throw new EnrollmentNotFound("No Enrollments For this Course Found");
		List<User> users = new ArrayList<>();
		for (int i = 0; i < list.size(); i++) {
			Enrollment enroll = list.get(i);
			users.add(userClient.getById(enroll.getUserId()));
		}
		return users;
	}


	@Override
	public List<Course> getCoursesByUserId(int userId) {
	    log.info("In EnrollmentServiceImpl getCoursesByUserId method...");
	    Boolean responseUser = userClient.checkUserExist(userId);
	    List<Enrollment> list = repository.findByUserId(userId);
	    List<Course> courses = new ArrayList<>();
	    for (Enrollment enroll : list) {
	        try {
	            Course course = courseClient.getCourse(enroll.getCourseId());
	            if (course != null) {
	                courses.add(course);
	            }
	        } catch (HttpClientErrorException.NotFound e) {
	            log.error("Course ID {} not found", enroll.getCourseId());
	        }
	    }
	    return courses;
	}

	@Override
	public UserCourseEnrollResponseDTO getEnrollment(int enrollmentId) throws EnrollmentNotFound {
		log.info("In EnrollmentServiceImpl getEnrollment method...");

		Optional<Enrollment> optional = repository.findById(enrollmentId);
		if (optional.isPresent()) {
			Enrollment enrollment = optional.get();
			int userId = enrollment.getUserId();
			int courseId = enrollment.getCourseId();
			// Communication with User Service
			User user = userClient.getById(userId);
			// Communication with Course service
			Course course = courseClient.getCourse(courseId);
			UserCourseEnrollResponseDTO responseDTO = new UserCourseEnrollResponseDTO(user, course, enrollment);
			return responseDTO;
		}
		throw new EnrollmentNotFound("Enrollment Id is Invalid");
	}


	@Override
	@Transactional
	public String cancelEnrollmentsCourseId(int courseId) {
		log.info("In EnrollmentServiceImpl cancelEnrollmentsCourseId method...");
		repository.deleteByCourseId(courseId);
		return "All the Enrollments For this Course Deleted";
	}

	@Override
	public Boolean checkEnrollmentByUserIdAndCourseId(int userId, int courseId) throws EnrollmentNotFound {
		log.info("In EnrollmentServiceImpl checkEnrollmentByUserIdAndCourseId method...");

		Boolean response = repository.existsByUserIdAndCourseId(userId, courseId);
		if (response)
			return response;
		else
			throw new EnrollmentNotFound("User Not Enrolled For This Course");
	}

	@Override
	public List<Enrollment> getEnrollmentsByCourseId(int courseId) {
	    log.info("Fetching enrollments for Course ID: {}", courseId);
	    List<Enrollment> enrollments = repository.findByCourseId(courseId);
	    
	    if (enrollments.isEmpty()) {
	        log.warn("No enrollments found for Course ID: {}", courseId);
	    }
	    
	    return enrollments;
	}
	
	@Override
	public List<Course> getAllCourses() {
	    log.info("Fetching all courses from Course Service...");

	    try {
	        List<Course> allCourses = courseClient.getAllCourses(); // Feign Client Call
	        if (allCourses.isEmpty()) {
	            log.warn("No courses found.");
	        }
	        return allCourses;
	    } catch (HttpClientErrorException e) {
	        log.error("Error fetching courses: {}", e.getMessage());
	        throw new RuntimeException("Failed to fetch courses from Course Service");
	    }
	}


}
