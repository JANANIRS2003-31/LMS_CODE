import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { QuizService } from '../quiz.service';
import { CommonServiceService } from '../common-service.service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { interval, Subscription } from 'rxjs';

@Component({
  selector: 'quiz-attempt',
  imports: [FormsModule, CommonModule],
  templateUrl: './quiz-attempt.component.html',
  styleUrls: ['./quiz-attempt.component.css']
})
export class QuizAttemptComponent implements OnInit, OnDestroy {
  quizId!: number;
  courseId!: number;
  userId!: number;
  quizDetails: any = {};
  submissionDetails: any = null;
  userAnswers: { [key: number]: string } = {};
  isLoading: boolean = true;
  isTakingQuiz: boolean = false;

  timeLeft: number = 300; // 5 minutes
  timerSubscription!: Subscription;

  constructor(
    private route: ActivatedRoute,
    private quizService: QuizService,
    private commonService: CommonServiceService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.quizId = Number(this.route.snapshot.paramMap.get('id'));

    this.commonService.getUserId().subscribe({
      next: (userId) => {
        this.userId = userId;

        if (!this.quizId || !this.userId) {
          console.error('Invalid Quiz or User ID');
          return;
        }

        this.fetchQuizDetails();
        this.checkQuizSubmission();
        this.startTimer(); // Start quiz timer
      },
      error: (err) => console.error('Error fetching user ID:', err)
    });
  }

  startTimer(): void {
    this.timerSubscription = interval(1000).subscribe(() => {
      if (this.timeLeft > 0) {
        this.timeLeft--;
      } else {
        this.timerSubscription.unsubscribe();
        this.autoSubmitQuiz();
      }
    });
  }

  autoSubmitQuiz(): void {
    alert("Time's up! Submitting quiz...");
    this.submitQuiz(); // Call existing submission function
  }

  fetchQuizDetails(): void {
    this.quizService.getQuizById(this.quizId).subscribe({
      next: (quiz) => {
        this.quizDetails = quiz;
        this.isLoading = false;
        this.courseId = quiz.courseId;
        console.log("Fetched Quiz Details:", this.quizDetails);
      },
      error: (err) => console.error('Error fetching quiz:', err)
    });
  }

  checkQuizSubmission(): void {
    this.quizService.getQuizSubmissionByUserIdAndQuizId(this.userId, this.quizId).subscribe({
      next: (submission) => {
        this.submissionDetails = submission;
        console.log("Fetched Quiz Submission:", this.submissionDetails);
      },
      error: () => {
        this.submissionDetails = null;
        console.warn("No previous submission found. User can attempt the quiz.");
      }
    });
  }

  startQuiz(): void {
    console.log("Starting quiz for Quiz ID:", this.quizId);
    this.isTakingQuiz = true;
    this.userAnswers = {};
  }

  goBack(): void {
    this.router.navigate([`/coursecontent/${this.courseId}/quizzes`]);
  }

  reattemptQuiz(): void {
  if (!this.submissionDetails || this.submissionDetails.passed) {
    return; // No need for reattempt if the user passed
  }

  // Reset responses for reattempt
  this.userAnswers = {};
  this.submissionDetails.score = 0;
  this.submissionDetails.passed = false;

  this.quizService.updateQuizSubmission(this.quizId, this.userId, this.userAnswers).subscribe({
    next: () => {
      console.log("Quiz reattempt started!");
      this.startQuiz(); // Restart the quiz attempt
    },
    error: err => console.error("Error updating submission for reattempt:", err)
  });
}

  
  submitQuiz(): void {
    if (this.timerSubscription) {
        this.timerSubscription.unsubscribe(); // Stop timer before submitting
    }

    const formattedResponses = Object.keys(this.quizDetails.questions).reduce((acc, key) => {
        acc[Number(key)] = this.userAnswers[key] || '';
        return acc;
    }, {} as { [key: number]: string });

    const quizSubmission = {
        quizId: this.quizId,
        userId: this.userId,
        responses: formattedResponses
    };

    this.quizService.submitQuiz(quizSubmission).subscribe({
        next: (result) => {
            console.log("Quiz Submission Result:", result);
            this.submissionDetails = result;
            this.submissionDetails.status = "Completed"; // **Set status to 'Completed'**
            this.isTakingQuiz = false;
        },
        error: (err) => {
            console.error("Error submitting quiz:", err);
            alert("Quiz submission failed. Please try again.");
        }
    });
}

  ngOnDestroy(): void {
    if (this.timerSubscription) {
      this.timerSubscription.unsubscribe(); // Clean up timer when component is destroyed
    }
  }
}
